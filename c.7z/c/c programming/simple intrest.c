#include<stdio.h>
int main() {
    float p,r,t,si;
    p=100;
    r=10;
    t=2;
    si=(p*t*r)/100;
    printf("%f",si);
    return 0;
}
