#include<stdio.h>
int main() {
    int i,k,j,ch,n;
for(int i=1;i<=n;i++){
    int a=1;
    for(int j=1;j<=n-i;j++){
        int d=a+64;
        char ch=(char)d;
        printf(" ");
        a++;
    }
    for (int k=1;k<=i;k++){
        printf("%c",ch);
    }
    printf("\n");
}
return 0;
}
