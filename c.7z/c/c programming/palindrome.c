#include <stdio.h>
#include <string.h>
int main ()
{
	char str[20],rev[20];
	int i, length;j=0;
	printf ("enter an string:\n");
	scanf ("%s",str);
	length=strlen(name);
	for  (i=length-1;i>=0,i--)
	{
		rev [j]=str[i]
		j++;
	}
	print ("The reverse string  in is %",rev);
	return 0;
	}
