#include<stdio.h>
int main() {
    int n;
    for(int i=1;i<=10;i=i+2){
      scanf("%d ",&n);
        printf("enter a number:");
    }
return 0;
}