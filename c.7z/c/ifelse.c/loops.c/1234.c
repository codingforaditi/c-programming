#include<stdio.h>
int main() {
int i,j;
for(int i=1;i<=5;i++){
    for (int j=1;j<5+1-i;j++){
        printf("%d",j);
    }
    printf("\n");
}
return 0;
}