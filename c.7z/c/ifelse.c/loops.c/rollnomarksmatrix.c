#include <stdio.h>
#define ROWS 4
#define COLS 2
int main() {
    int matrix[ROWS][COLS];
    int i, j;

    // Input roll numbers and marks for each student
    printf("Enter roll numbers and marks for each student:\n");
    for (i = 0; i < ROWS; i++) {
        printf("For student %d:\n", i + 1);
        printf("Enter roll number: ");
        scanf("%d", &matrix[i][0]); // Roll number stored in the first column
        printf("Enter marks obtained: ");
        scanf("%d", &matrix[i][1]); // Marks stored in the second column
    }

    // Display the matrix
    printf("\nRoll Number Marks\n");
    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLS; j++) {
            printf("%d", matrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}
