#include<stdio.h>
void main()
{
int i=1;
do
{
printf("Hello First Semester\n");
i=i+1;
} while(i<=5);
printf("%c",i);
return 0;
}