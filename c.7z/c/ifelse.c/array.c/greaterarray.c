#include<stdio.h>
int count;
    int arr[7]={1,2,3,4,5,6,7};
    int x=4;
    int greater,i;
    int count=0;
    for (int i=0;i<6;i++){
        if (arr[i]>x){
         count++;
        }
    }
    return count;