#include<stdio.h>
int main(){
    int arr[]={-1,2,3,4,5};
    int min=arr[0];
    for(int i=0;i<=5;i++){
    if (min>arr[i]){
        min=arr[i];
    }
    }
    printf("%d",min);
    return 0;
}