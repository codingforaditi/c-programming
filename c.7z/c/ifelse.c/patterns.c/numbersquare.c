#include<stdio.h>
int main(){
    int i,j,n;
    for(int i=1;i<=4;i++){
        for(int j=1;j<=3;j++){
            printf("%d ",j);
        }
        printf("\n");
        }
        return 0;
    }