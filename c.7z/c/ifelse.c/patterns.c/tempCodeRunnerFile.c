#include<stdio.h>
int main() {
    int i,k,j,n;
    printf("enter no of lines:");
    scanf("%d",&n);
    int nst=1;
    for(int i=1;i<=n;i++){
        for (int k=1;k<=n-i;k++){