#include<stdio.h>
int main(){
    for(int i=1;i<=3;i++){
        for(int i=1;i<=5;i++){
            printf("*");
        }
        printf("\n");
        }
        return 0;
    }