#include<stdio.h>
int main()
{
    double=x2,y1,y2,x3,x4,y3,x1;
    printf("enter a number:");
    double m1=(y2-y1)/(x2-x1);


}