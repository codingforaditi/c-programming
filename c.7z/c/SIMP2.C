#include <stdio.h>
#include <math.h>

double f(double x) {
    return exp(-x * x);
}

int main() {
    double a = 0, b = 1;
    int n = 4;

    // h should be calculated using n
    double h = (b - a) / n;
    double sum = f(a) + f(b);

    for (int i = 1; i < n; i++) {
        double x = a + i * h;
        if (i % 2 == 0)
            sum += 2 * f(x);
        else
            sum += 4 * f(x);
    }

    double result = (h / 3) * sum;

    printf("Approximate integral using Simpson's 1/3 rule with %d subintervals: %lf\n", n, result);
    return 0;
}
