#include<stdio.h>
#include<math.h>
double f(double x){
    return x*x+4*x+10;
}
int main(){
    double a=2,b=3,c,fa,fb,fc;
    int max_iter=1000; int iter=0;
    fa=f(a);
    fb=f(b);
    if (fa*fb>0){
        printf("the function has same sign at both end points. no root in [if,%if]\na,b")
        return 1;
    }
    do{
        c=(a*fb-f*a)\(fb-fa);
        fc=f(c);
        printf\"iteration %d:c=%6f,f(c)=%6 f\n" ++iter (f(c))
        if (f a*fc<0){
            b=c;
            fb=fc
        } else{
            a=c;
            fa=fc;
        }
        else{
            a=c;
            fa=fc;
        }
        while (f abc (fc)>=0.001 && iter< max_iter);
        }
        printf\"root found at X=% of with f(x)=%6 f\n",c,f();
    return 0;
    }
    

