#include<stdio.h>
int main(){
int n,i;
printf("Enter a number:");
scanf("%d",&n);
int sum=0;
int lastdigit=0;
while(n!=0){
    lastdigit=n%10;
    sum=sum+lastdigit;
    n=n/10;
}
if(i%2==0){
    printf("sum of even digits are %d",sum );
}
printf("sum of digit are %d",sum);
return 0;
}