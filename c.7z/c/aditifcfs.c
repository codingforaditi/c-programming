#include <stdio.h>

struct process {
    int pid;
    int bt;
    int wt, tt;
} p[10];

int main() {
    int i, n, totwt = 0, tottt = 0, avg1, avg2;

    printf("Enter the number of processes:\n");
    scanf("%d", &n);

    for(i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter the burst time for process %d: ", p[i].pid);
        scanf("%d", &p[i].bt);
    }

    p[0].wt = 0;
    p[0].tt = p[0].bt;

    for(i = 1; i < n; i++) {
        p[i].wt = p[i - 1].bt + p[i - 1].wt;
        p[i].tt = p[i].bt + p[i].wt;
    }

    printf("\nProcess ID\tBT\tWT\tTT\n");

    for(i = 0; i < n; i++) {
        printf("\t%d\t%d\t%d\t%d\n", p[i].pid, p[i].bt, p[i].wt, p[i].tt);
        totwt += p[i].wt;
        tottt += p[i].tt;
    }

    avg1 = totwt / n;
    avg2 = tottt / n;

    printf("\nAverage Waiting Time = %d", avg1);
    printf("\nAverage Turnaround Time = %d\n", avg2);

    return 0;
}
