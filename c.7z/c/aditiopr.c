#include<stdio.h>

int i,j,nof,nor,flag=0,ref[50],frm[50],pf=0,victim=-1;
int optcal[50],count=0;
int optvictim(int index);

int main() {
    printf("\nOPTIMAL PAGE REPLACEMENT ALGORITHM\n");
    printf("Enter number of frames: ");
    scanf("%d",&nof);
    printf("Enter number of reference string: ");
    scanf("%d",&nor);
    printf("Enter the reference string:\n");
    for(i=0;i<nor;i++)
        scanf("%d",&ref[i]);

    for(i=0;i<nof;i++) {
        frm[i]=-1;
        optcal[i]=0;
    }

    for(i=0;i<nor;i++) {
        flag=0;
        printf("\nref no %d ->\t",ref[i]);
        for(j=0;j<nof;j++) {
            if(frm[j]==ref[i]) {
                flag=1;
                break;
            }
        }
        if(flag==0) {
            count++;
            if(count<=nof)
                victim++;
            else
                victim=optvictim(i);
            pf++;
            frm[victim]=ref[i];
            for(j=0;j<nof;j++)
                printf("%4d",frm[j]);
        }
    }
    printf("\nNumber of page faults: %d\n",pf);
    return 0;
}

int optvictim(int index) {
    int i,j,notfound;
    for(i=0;i<nof;i++) {
        notfound=1;
        for(j=index;j<nor;j++) {
            if(frm[i]==ref[j]) {
                optcal[i]=j;
                notfound=0;
                break;
            }
        }
        if(notfound==1)
            return i;
    }
    int farthest=optcal[0],victimIndex=0;
    for(i=1;i<nof;i++) {
        if(optcal[i]>farthest) {
            farthest=optcal[i];
            victimIndex=i;
        }
    }
    return victimIndex;
}
