#include<stdio.h>
#include <math.h>
double f(double x){
    return exp (-x*x);

}
int main(){
    double a=0;double b=1;
    int n=4;
    double h=(b-a)/h;
    double sum = f(a)+f(b);
    for (int i=1;i<h;i++){
        double x=a+i*h;
        if (i%2=0)
        sum+=2*f(x);
        else 
        sum+4*f(x);
    }
    double result =(h/3)*sum;
     printf\"approximate integral using simpson's 1/3 rule with h=4 subintervals result\"
     return 0;

    }