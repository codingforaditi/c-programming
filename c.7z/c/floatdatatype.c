#include <stdio.h>
int main()
{
    float x=5;
    float y=2;
    printf("%f",x/y);
    return 0;
}