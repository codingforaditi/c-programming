#include<stdio.h>
int main() {
    float m1 = 100;
    float m2 =28;
    float m3 =20;
    float m4 = 35;
    float p=(m1+m2+m3+m4)/4;
    printf("percentage of 4 subjects is:%f",p);
    return 0;
}