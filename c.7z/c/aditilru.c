#include <stdio.h>

int i, j, nof, nor, flag = 0, ref[50], frm[50], pf = 0, victim = -1;
int recent[50];
int lruvictim();

int main() {
    printf("\n\t\t\tLRU PAGE REPLACEMENT ALGORITHM\n");
    printf("Enter number of Frames: ");
    scanf("%d", &nof);
    printf("Enter number of Reference string: ");
    scanf("%d", &nor);
    printf("Enter Reference string:\n");
    for (i = 0; i < nor; i++)
        scanf("%d", &ref[i]);

    for (i = 0; i < nof; i++) {
        frm[i] = -1;
        recent[i] = 0;
    }

    printf("\nThe given reference string:\n");
    for (i = 0; i < nor; i++)
        printf("%4d", ref[i]);
    printf("\n");

    for (i = 0; i < nor; i++) {
        flag = 0;
        printf("\nReference No %d ->\t", ref[i]);

        for (j = 0; j < nof; j++) {
            if (frm[j] == ref[i]) {
                flag = 1;
                break;
            }
        }

        if (flag == 0) {
            pf++;
            if (victim < nof - 1)
                victim++;
            else
                victim = lruvictim();

            frm[victim] = ref[i];
        }

        for (j = 0; j < nof; j++)
            printf("%4d", frm[j]);

        recent[ref[i]] = i;
    }

    printf("\n\nNumber of Page Faults: %d\n", pf);

    return 0;
}

int lruvictim() {
    int i, lru_index = 0, min_recent;

    min_recent = recent[frm[0]];
    for (i = 1; i < nof; i++) {
        if (recent[frm[i]] < min_recent) {
            min_recent = recent[frm[i]];
            lru_index = i;
        }
    }
    return lru_index;
}
