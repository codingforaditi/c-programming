#include<stdio.h>
#include<math.h>

int main() {
    int x, i, fact = 1, n;
    float sum = 1.0;

    printf("\n\nEnter the value of x in the series :  ");
    scanf("%d", &x);

    printf("\nEnter the number of terms in the series  :   ");
    scanf("%d", &n);

    for(i = 1; i < n; i++) {
        fact = fact * i;
        sum = sum + (pow(x, i) / fact);
    }

    printf("\nThe sum of the Taylor series is :  %.6f\n\n", sum);
    return 0;
}
