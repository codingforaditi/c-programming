#include<stdio.h>
int main() 
{
int radius =5;
float pi=3.14;
float area;
area =pi*radius*radius;
printf("%f",area);
return 0;
}